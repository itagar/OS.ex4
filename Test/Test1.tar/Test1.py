import subprocess as sp
import os
import filecmp


def clean():
    sp.call(["make", "clean"], cwd=os.getcwd(), stdout=sp.DEVNULL, stderr=sp.DEVNULL)


def fail(test_number):
    clean()
    print("Test", test_number, " failed :(")
    exit(-1)


def success(test_number):
    clean()
    print("Test", test_number, " passed!")


if __name__ == '__main__':
    print("Starting Test 1...")
    try:
        sp.check_call(["make", "Test1"], cwd=os.getcwd(), stdout=sp.DEVNULL, stderr=sp.DEVNULL)
        if not filecmp.cmp("BufferOutput", "BufferOutputResult"):
            fail(1)
        if not filecmp.cmp("CacheLog", "CacheLogResult"):
            fail(1)
        if not filecmp.cmp("StatLog", "StatLogResult"):
            fail(1)
        success(1)
    except sp.CalledProcessError as e:
        fail(1)