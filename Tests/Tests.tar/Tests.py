import subprocess as sp
import os
import filecmp


class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


def clean():
    sp.call(["make", "clean"], cwd=os.getcwd(), stdout=sp.DEVNULL, stderr=sp.DEVNULL)


def fail(test_number):
    clean()
    print(bcolors.FAIL + "Test", test_number, "failed :(" + bcolors.ENDC)


def success(test_number):
    clean()
    print(bcolors.OKGREEN + "Test", test_number, "passed!" + bcolors.ENDC)


def start_test(test_number):
    print(bcolors.WARNING + "Starting Test " + str(test_number) + "... " + bcolors.ENDC, end="")


def test1():
    start_test(1)
    try:
        sp.check_call(["make", "Test1"], cwd=os.getcwd(), stdout=sp.DEVNULL, stderr=sp.DEVNULL)
        if not filecmp.cmp("BufferOutput", "ResultFiles/BufferOutputResult1"):
            fail(1)
            return
        if not filecmp.cmp("CacheLog", "ResultFiles/CacheLogResult1"):
            fail(1)
            return
        if not filecmp.cmp("StatLog", "ResultFiles/StatLogResult1"):
            fail(1)
            return
        success(1)
        return
    except sp.CalledProcessError as e:
        fail(1)
        return


def test2():
    start_test(2)
    try:
        sp.check_call(["make", "Test2"], cwd=os.getcwd(), stdout=sp.DEVNULL, stderr=sp.DEVNULL)
        if not filecmp.cmp("BufferOutput", "ResultFiles/BufferOutputResult2"):
            fail(2)
            return
        if not filecmp.cmp("CacheLog", "ResultFiles/CacheLogResult2"):
            fail(2)
            return
        if not filecmp.cmp("StatLog", "ResultFiles/StatLogResult2"):
            fail(2)
            return
        success(2)
    except sp.CalledProcessError as e:
        fail(2)
        return


def test3():
    start_test(3)
    try:
        sp.check_call(["make", "Test3"], cwd=os.getcwd(), stdout=sp.DEVNULL, stderr=sp.DEVNULL)
        if not filecmp.cmp("BufferOutput", "ResultFiles/BufferOutputResult3"):
            fail(3)
            return
        if not filecmp.cmp("CacheLog", "ResultFiles/CacheLogResult3"):
            fail(3)
            return
        if not filecmp.cmp("StatLog", "ResultFiles/StatLogResult3"):
            fail(3)
            return
        success(3)
    except sp.CalledProcessError as e:
        fail(3)
        return


def test4():
    start_test(4)
    try:
        sp.check_call(["make", "Test4"], cwd=os.getcwd(), stdout=sp.DEVNULL, stderr=sp.DEVNULL)
        if not filecmp.cmp("BufferOutput", "ResultFiles/BufferOutputResult4"):
            fail(4)
            return
        if not filecmp.cmp("CacheLog", "ResultFiles/CacheLogResult4"):
            fail(4)
            return
        if not filecmp.cmp("StatLog", "ResultFiles/StatLogResult4"):
            fail(4)
            return
        success(4)
    except sp.CalledProcessError as e:
        fail(4)
        return


def test5():
    start_test(5)
    try:
        sp.check_call(["make", "Test5"], cwd=os.getcwd(), stdout=sp.DEVNULL, stderr=sp.DEVNULL)
        if not filecmp.cmp("BufferOutput", "ResultFiles/BufferOutputResult5"):
            fail(5)
            return
        if not filecmp.cmp("CacheLog", "ResultFiles/CacheLogResult5"):
            fail(5)
            return
        if not filecmp.cmp("StatLog", "ResultFiles/StatLogResult5"):
            fail(5)
            return
        success(5)
    except sp.CalledProcessError as e:
        fail(5)
        return


if __name__ == '__main__':
    test1()
    test2()
    test3()
    test4()
    test5()



