import subprocess as sp
import os
import filecmp


def clean():
    sp.call(["make", "clean"], cwd=os.getcwd(), stdout=sp.DEVNULL, stderr=sp.DEVNULL)


def fail(test_number):
    clean()
    print("Test", test_number, " failed :(")
    exit(-1)


def success(test_number):
    clean()
    print("Test", test_number, " passed!")


def test1():
    print("Starting Test 1...")
    try:
        sp.check_call(["make", "Test1"], cwd=os.getcwd(), stdout=sp.DEVNULL, stderr=sp.DEVNULL)
        if not filecmp.cmp("BufferOutput", "ResultFiles/BufferOutputResult1"):
            fail(1)
        if not filecmp.cmp("CacheLog", "ResultFiles/CacheLogResult1"):
            fail(1)
        if not filecmp.cmp("StatLog", "ResultFiles/StatLogResult1"):
            fail(1)
        success(1)
    except sp.CalledProcessError as e:
        fail(1)


def test2():
    print("Starting Test 2...")
    try:
        sp.check_call(["make", "Test2"], cwd=os.getcwd(), stdout=sp.DEVNULL, stderr=sp.DEVNULL)
        if not filecmp.cmp("BufferOutput", "ResultFiles/BufferOutputResult2"):
            fail(2)
        if not filecmp.cmp("CacheLog", "ResultFiles/CacheLogResult2"):
            fail(2)
        if not filecmp.cmp("StatLog", "ResultFiles/StatLogResult2"):
            fail(2)
        success(2)
    except sp.CalledProcessError as e:
        fail(2)


def test3():
    print("Starting Test 3...")
    try:
        sp.check_call(["make", "Test3"], cwd=os.getcwd(), stdout=sp.DEVNULL, stderr=sp.DEVNULL)
        if not filecmp.cmp("BufferOutput", "ResultFiles/BufferOutputResult3"):
            fail(3)
        if not filecmp.cmp("CacheLog", "ResultFiles/CacheLogResult3"):
            fail(3)
        if not filecmp.cmp("StatLog", "ResultFiles/StatLogResult3"):
            fail(3)
        success(3)
    except sp.CalledProcessError as e:
        fail(3)


def test4():
    print("Starting Test 4...")
    try:
        sp.check_call(["make", "Test4"], cwd=os.getcwd(), stdout=sp.DEVNULL, stderr=sp.DEVNULL)
        if not filecmp.cmp("BufferOutput", "ResultFiles/BufferOutputResult4"):
            fail(4)
        if not filecmp.cmp("CacheLog", "ResultFiles/CacheLogResult4"):
            fail(4)
        if not filecmp.cmp("StatLog", "ResultFiles/StatLogResult4"):
            fail(4)
        success(4)
    except sp.CalledProcessError as e:
        fail(4)


def test5():
    print("Starting Test 5...")
    try:
        sp.check_call(["make", "Test5"], cwd=os.getcwd(), stdout=sp.DEVNULL, stderr=sp.DEVNULL)
        if not filecmp.cmp("BufferOutput", "ResultFiles/BufferOutputResult5"):
            fail(5)
        if not filecmp.cmp("CacheLog", "ResultFiles/CacheLogResult5"):
            fail(5)
        if not filecmp.cmp("StatLog", "ResultFiles/StatLogResult5"):
            fail(5)
        success(5)
    except sp.CalledProcessError as e:
        fail(5)


if __name__ == '__main__':
    test1()
    test2()
    test3()
    test4()
    test5()



